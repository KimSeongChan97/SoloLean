package com.control;

import com.dao.MemberDAO;
import com.dto.MemberDTO;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@WebServlet
public class ControlServlet extends HttpServlet {
    private Connection conn;

    public void init() throws ServletException {
        try {
            // 데이터베이스 연결 초기화
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbname", "username", "password");
        } catch (ClassNotFoundException | SQLException e) {
            throw new ServletException(e);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        MemberDAO memberDAO = new MemberDAO(conn);

        if (action.equals("signup")) {
            // 회원가입 처리
            String id = request.getParameter("id");
            String pwd = request.getParameter("pwd");
            String name = request.getParameter("name");
            String gender = request.getParameter("gender");
            String birth1 = request.getParameter("birth1");
            String birth2 = request.getParameter("birth2");
            String birth3 = request.getParameter("birth3");
            String email1 = request.getParameter("email1");
            String email2 = request.getParameter("email2");
            String tel1 = request.getParameter("tel1");
            String tel2 = request.getParameter("tel2");
            String tel3 = request.getParameter("tel3");

            MemberDTO member = new MemberDTO(id, pwd, name, gender, birth1, birth2, birth3, email1, email2, tel1, tel2, tel3);
            try {
                memberDAO.insert(member);
                response.sendRedirect("signupSuccess.jsp");
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp");
            }
        } else if (action.equals("login")) {
            // 로그인 처리
            String id = request.getParameter("id");
            String pwd = request.getParameter("pwd");

            try {
                MemberDTO member = memberDAO.login(id, pwd);
                if (member != null) {
                    HttpSession session = request.getSession();
                    session.setAttribute("member", member);
                    response.sendRedirect("welcome.jsp");
                } else {
                    response.sendRedirect("loginFail.jsp");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("error.jsp");
            }
        }
    }

    public void destroy() {
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}