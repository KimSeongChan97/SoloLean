package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.ibatis.session.SqlSession;

import com.dto.MemberDTO;

public class MemberDAO {
	private SqlSession sqlSession;
	
	public MemberDAO(SqlSession sqlSession) {
        this.sqlSession = sqlSession;
    }

    // 회원가입 메서드
    public void insertUser(MemberDTO memberDTO) throws SQLException {
    	sqlSession.insert("com.example.mapper.UserMapper.insertUser", user);
    }

    // 로그인 메서드
    public MemberDTO loginUser(Map<String, String> paramMap) throws SQLException {
    	return sqlSession.selectOne("com.example.mapper.UserMapper.loginUser", paramMap);
    }
}
