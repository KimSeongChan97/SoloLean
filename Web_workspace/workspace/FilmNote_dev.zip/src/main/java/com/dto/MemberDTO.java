package com.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberDTO {
    private String id;        // 회원 아이디
    private String pwd;       // 회원 비밀번호
    private String name;      // 회원 이름
    private String gender;    // 성별
    private String birth1;    // 생년 (YYYY)
    private String birth2;    // 생월 (MM)
    private String birth3;    // 생일 (DD)
    private String email1;    // 이메일 아이디
    private String email2;    // 이메일 도메인
    private String tel1;      // 휴대폰 앞자리
    private String tel2;      // 휴대폰 가운데 자리
    private String tel3;      // 휴대폰 끝자리

    // 기본 생성자
    public MemberDTO() {}

    // 생성자
    public MemberDTO(String id, String pwd, String name, String gender, String birth1, String birth2, String birth3,
                     String email1, String email2, String tel1, String tel2, String tel3) {
        this.id = id;
        this.pwd = pwd;
        this.name = name;
        this.gender = gender;
        this.birth1 = birth1;
        this.birth2 = birth2;
        this.birth3 = birth3;
        this.email1 = email1;
        this.email2 = email2;
        this.tel1 = tel1;
        this.tel2 = tel2;
        this.tel3 = tel3;
    }

    
}
