package com.cont;

import com.example.dao.UserDAO;
import com.example.domain.User;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class UserController extends HttpServlet {
    private SqlSessionFactory sqlSessionFactory;

    public UserController(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        SqlSession sqlSession = sqlSessionFactory.openSession();
        UserDAO userDAO = new UserDAO(sqlSession);

        if ("signup".equals(action)) {
            // 회원가입 처리
            User user = new User();
            user.setUsername(request.getParameter("username"));
            user.setUserid(request.getParameter("userid"));
            user.setPassword(request.getParameter("password"));
            user.setEmail(request.getParameter("email"));
            user.setPhone(request.getParameter("phone"));
            userDAO.insertUser(user);
            sqlSession.commit();
            response.sendRedirect("userSignIn.jsp");
        } else if ("login".equals(action)) {
            // 로그인 처리
            String userid = request.getParameter("userid");
            String password = request.getParameter("password");
            Map<String, String> paramMap = new HashMap<>();
            paramMap.put("userid", userid);
            paramMap.put("password", password);
            User user = userDAO.loginUser(paramMap);
            if (user != null) {
                request.getSession().setAttribute("user", user);
                response.sendRedirect("welcome.jsp");
            } else {
                response.sendRedirect("userSignIn.jsp?error=1");
            }
        }
        sqlSession.close();
    }
}