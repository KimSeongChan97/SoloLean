package homework;

public class Game {

	public static void main(String[] args) {
		

	}

}

/*
[문제] 가위 바위 보 게임
- 가위(1), 바위(2), 보자기(3)으로 설정한다.
- 컴퓨터는 난수 1 ~ 3 사이의 숫자를 발생한다.
- 기본 금액은 1000원을 기본으로 설정한다.
- System.in.read() 사용하여 입력 받는다.

[실행결과]
가위(1), 바위(2), 보자기(3) 입력 : 1  ← System.in.read() 사용
배팅 금액 : 600

결과를 보시려면 Enter를 치세요

컴퓨터 바위, 나는 가위
ㅠㅠ..졌다
현재 금액은 400윈

*/





