package homework;

public class If {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/*
[문제] 3개의 숫자(a,b,c)를 입력받아서 순서대로 출력하시오
- Scanner, if문 사용하시오

[실행결과]
a의 값 : 98
b의 값 : 90
c의 값 : 85

85 90 98

a의 값 : 75
b의 값 : 25
c의 값 : 36

25 36 75
*/






